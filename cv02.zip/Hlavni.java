
public class Hlavni {

	//private Osoba[] pole;
	//private Student[] poleStudentu;
	
	public static void main(String[] args) {
		//Hlavni hl = new Hlavni();
		//hl.pole = new Osoba [5];
		//hl.poleStudentu = new Student [5];
		
		Osoba[] pole = new Osoba[7];
		
		Osoba os = new Osoba("Jakub", "Vanek", 24, 10, 1996);
		//System.out.println(os.toString());
		
		Student s = new Student("kamil", "hoffman", 1, 2, 2003, "3G", "3G001");
		//System.out.println(s.toString());
		
		Zamestnanec z = new Zamestnanec("James", "Bond", 1,2,2000, "Agent", "007 bitch" );
		//System.out.println(z.toString());
		
		pole[0] = new Student("Ruda", "Puda", 12,7,2014, "S002", "1.A");
		pole[1] = new Student("Ku�ivoj", "Vysajbong", 2,6,2016, "S004", "3.B");
		pole[2] = new Zamestnanec("James", "Bond", 1,2,2000, "Agent", "007 bitch" );
		pole[3] = new Osoba("Karolina", "Ori", 1,9,1996);
		pole[4] = new Osoba();
		pole[5] = new Student();
		pole[6] = new Zamestnanec();
		
		for (Osoba osoba : pole) {
			System.out.println(osoba);
		}
		
		/*for (int i = 0; i < pole.length; i++) {
			System.out.println( i + ". - " + pole[i]);
		}*/
		
		
		
	}

}
