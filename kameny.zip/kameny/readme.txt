Aplikaci spustíte poklepáním na soubor "kameny.jar".

!!!! Složka img se nesmí přejmenovat a musí být ve stejné složce jako soubor kameny.jar !!!!

Do aplikace je možné přidat další kameny následujícím způsobem:
	Uložíte si obrázek požadovaného kamene.
	Kámen musí mít název <nazev>.<pripona> ( mela by fungovat jakakoliv pripona, doporuceno vsak .png).
	Obrázek s kamenem uložíte do složky img.
	Následně by se měl kámen také zobrazovat v aplikaci.


Ovládání aplikace: 
	V aplikaci vyberete název kamene, který je na obrázku a stisknete tlačítko confirm.
	Pokud jste vybrali správně, bude vám nabídnut další kámen.
	Pokud jste vybrali špatně, kámen zůstane na obrazovce.


pozn.:

Dělal jsem to asi hodinu, abych pomohl.. Aplikace podle toho vypadá, takže poznávej a No Hate <3
