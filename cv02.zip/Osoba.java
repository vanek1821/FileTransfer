
public class Osoba {
	
	private String jmeno;
	private String prijmeni;
	private int den;
	private int mesic;
	private int rok;
	
	public Osoba(String jmeno, String prijmeni, int den, int mesic, int rok) {
		this.jmeno = jmeno;
		this.setPrijmeni(prijmeni);
		this.setDen(den);
		this.setMesic(mesic);
		this.setRok(rok);
	}
	
	public Osoba() {
		this("Prokop", "Buben", 1, 1, 2001);
	}
	
	public String getJmeno() {
		return this.jmeno;
	}
	
	public void setJmeno(String jmeno) {
		this.jmeno = jmeno;
	}

	public String getPrijmeni() {
		return prijmeni;
	}

	public void setPrijmeni(String prijmeni) {
		this.prijmeni = prijmeni;
	}

	public int getDen() {
		return den;
	}

	public void setDen(int den) {
		this.den = den;
	}

	public int getRok() {
		return rok;
	}

	public void setRok(int rok) {
		this.rok = rok;
	}

	public int getMesic() {
		return mesic;
	}

	public void setMesic(int mesic) {
		this.mesic = mesic;
	}
	
	public String toString() {
		return "jmeno: " + this.getJmeno() +
				" prijmeni: " + this.getPrijmeni() + 
				" rok narozeni: " + this.getDen()  + "." + this.getMesic() + "." + this.getRok();
		
	}
}
