
public class Student extends Osoba{
	
	private String sID;
	private String trida;
		
	public Student(String jmeno, String prijmeni, int den, int mesic, int rok, String trida, String sID) {
		super(jmeno, prijmeni, den, mesic, rok);
		this.setTrida(trida);
		this.setsID(sID);
	}
	
	public Student() {
		super();
		this.sID = "S0001";
		this.trida = "1.A";
	}

	public String getsID() {
		return sID;
	}

	public void setsID(String sID) {
		this.sID = sID;
	}

	public String getTrida() {
		return trida;
	}

	public void setTrida(String trida) {
		this.trida = trida;
	}
	
	public String toString() {
		return "Student - " + super.toString() + " SID: " + this.getsID() + " trida: " + this.getTrida();
	}
}
