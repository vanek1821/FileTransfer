
public class Zamestnanec extends Osoba{
	//profese
	//zID
	private String profese;
	private String zID;	
	
	public Zamestnanec(String jmeno, String prijmeni, int den, int mesic, int rok, String profese, String zID) {
		super(jmeno, prijmeni, den, mesic, rok);
		this.setProfese(profese);
		this.setzID(zID);
	}

	public Zamestnanec() {
		super();
		this.setProfese("�idi� kamionu");
		this.setzID("NaN");
	}
	public String getProfese() {
		return profese;
	}

	public void setProfese(String profese) {
		this.profese = profese;
	}

	public String getzID() {
		return zID;
	}
	
	public String toString() {
		return "Zamestnanec - " + super.toString() + " ZID: " + this.getzID() + " profese: " + this.getProfese();
	}

	public void setzID(String zID) {
		this.zID = zID;
	}

}
